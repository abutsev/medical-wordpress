=== Medical Consulting ===

Contributors: keonthemes
Tags: blog, portfolio, education, grid-Layout, two-columns, flexible-header, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, featured-images, full-width-template, post-formats, rtl-language-support, theme-options, sticky-post, threaded-comments, translation-ready, block-styles, wide-blocks
Requires at least: 4.7
Requires PHP: 5.5
Tested up to: 5.4.2
Stable tag: 1.0.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Medical Consulting WordPress Theme is child theme of Business Consultr, Copyright 2020 Keon Themes
Medical Consulting is distributed under the terms of the GNU General Public License v3

== Description ==

Medical Consulting is a beautiful and elegant blue and green color schemed child theme of Business Consultr. Theme Demo: https://keonthemes.com/theme-demo/?id=MjA0NXxlZHVjYXRpb24tY29uc3VsdHJ8RWR1Y2F0aW9uIENvbnN1bHRy

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Medical Consulting includes support for WooCommerce and Contact From 7.

== Changelog ==

= 1.0.1 =
* Minor Style Fixed.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.1 =
* This version fixed Minor Style issues.

= 1.0.0 =
* Initial release.

== Resources ==
* Image for theme screenshot, Copyright pxhere.com
  License: CC0
  Source: https://pxhere.com/en/photo/1430845
  Source: https://pxhere.com/en/photo/480543