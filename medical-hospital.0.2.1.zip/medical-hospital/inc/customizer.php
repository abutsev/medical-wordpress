<?php
/**
 * Medical Hospital Theme Customizer
 * @package Medical Hospital
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */

function medical_hospital_customize_register( $wp_customize ) {	

	//add home page setting pannel
	$wp_customize->add_panel( 'medical_hospital_panel_id', array(
	    'priority' => 10,
	    'capability' => 'edit_theme_options',
	    'theme_supports' => '',
	    'title' => __( 'Theme Settings', 'medical-hospital' ),
	    'description' => __( 'Description of what this panel does.', 'medical-hospital' ),
	) );

	//layout setting
	$wp_customize->add_section( 'medical_hospital_theme_layout', array(
    	'title'      => __( 'Layout Settings', 'medical-hospital' ),
		'priority'   => null,
		'panel' => 'medical_hospital_panel_id'
	) );

	// Add Settings and Controls for Layout
	$wp_customize->add_setting('medical_hospital_layout',array(
	        'default' => __( 'Right Sidebar', 'medical-hospital' ),
	        'sanitize_callback' => 'medical_hospital_sanitize_choices'	        
	    )
    );

	$wp_customize->add_control('medical_hospital_layout',
	    array(
	        'type' => 'radio',
	        'label' => __( 'Do you want this section', 'medical-hospital' ),
	        'section' => 'medical_hospital_theme_layout',
	        'choices' => array(
	            'Left Sidebar' => __('Left Sidebar','medical-hospital'),
	            'Right Sidebar' => __('Right Sidebar','medical-hospital'),
	            'One Column' => __('One Column','medical-hospital'),
	            'Three Columns' => __('Three Columns','medical-hospital'),
	            'Four Columns' => __('Four Columns','medical-hospital'),
	            'Grid Layout' => __('Grid Layout','medical-hospital')
	        ),
	    )
    );

    //Social Icons(topbar)
	$wp_customize->add_section('medical_hospital_social_media',array(
		'title'	=> __('Social Icon','medical-hospital'),
		'description'	=> __('Add Header Content here','medical-hospital'),
		'priority'	=> null,
		'panel' => 'medical_hospital_panel_id',
	));

	$wp_customize->add_setting('medical_hospital_facebook',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('medical_hospital_facebook',array(
		'label'	=> __('Add Facebook link','medical-hospital'),
		'section'	=> 'medical_hospital_social_media',
		'setting'	=> 'medical_hospital_facebook',
		'type'		=> 'url'
	));

	$wp_customize->add_setting('medical_hospital_twitter',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('medical_hospital_twitter',array(
		'label'	=> __('Add Twitter link','medical-hospital'),
		'section'	=> 'medical_hospital_social_media',
		'setting'	=> 'medical_hospital_twitter',
		'type'	=> 'url'
	));

	$wp_customize->add_setting('medical_hospital_google',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('medical_hospital_google',array(
		'label'	=> __('Add Google Plus link','medical-hospital'),
		'section'	=> 'medical_hospital_social_media',
		'setting'	=> 'medical_hospital_google',
		'type'	=> 'url'
	));

	$wp_customize->add_setting('medical_hospital_pintrest',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('medical_hospital_pintrest',array(
		'label'	=> __('Add Pintrest link','medical-hospital'),
		'section'	=> 'medical_hospital_social_media',
		'setting'	=> 'medical_hospital_pintrest',
		'type'	=> 'url'
	));

	$wp_customize->add_setting('medical_hospital_insta',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('medical_hospital_insta',array(
		'label'	=> __('Add Instagram link','medical-hospital'),
		'section'	=> 'medical_hospital_social_media',
		'setting'	=> 'medical_hospital_insta',
		'type'	=> 'url'
	));

	$wp_customize->add_setting('medical_hospital_linkdin',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('medical_hospital_linkdin',array(
		'label'	=> __('Add Linkdin link','medical-hospital'),
		'section'	=> 'medical_hospital_social_media',
		'setting'	=> 'medical_hospital_linkdin',
		'type'	=> 'url'
	));

	$wp_customize->add_setting('medical_hospital_youtube',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('medical_hospital_youtube',array(
		'label'	=> __('Add Youtube link','medical-hospital'),
		'section'	=> 'medical_hospital_social_media',
		'setting'	=> 'medical_hospital_youtube',
		'type'	=> 'url'
	));


	//Topbar section
	$wp_customize->add_section('medical_hospital_topbar_icon',array(
		'title'	=> __('Topbar Section','medical-hospital'),
		'description'	=> __('Add Header Content here','medical-hospital'),
		'priority'	=> null,
		'panel' => 'medical_hospital_panel_id',
	));

	$wp_customize->add_setting('medical_hospital_time',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('medical_hospital_time',array(
		'label'	=> __('Add Time','medical-hospital'),
		'section'	=> 'medical_hospital_topbar_icon',
		'setting'	=> 'medical_hospital_time',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('medical_hospital_time1',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('medical_hospital_time1',array(
		'label'	=> __('Add Time','medical-hospital'),
		'section'	=> 'medical_hospital_topbar_icon',
		'setting'	=> 'medical_hospital_time1',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('medical_hospital_phone',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('medical_hospital_phone',array(
		'label'	=> __('Add Contact','medical-hospital'),
		'section'	=> 'medical_hospital_topbar_icon',
		'setting'	=> 'medical_hospital_phone',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('medical_hospital_phone1',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('medical_hospital_phone1',array(
		'label'	=> __('Add Contact','medical-hospital'),
		'section'	=> 'medical_hospital_topbar_icon',
		'setting'	=> 'medical_hospital_phone1',
		'type'		=> 'text'
	));	

	$wp_customize->add_setting('medical_hospital_address',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('medical_hospital_address',array(
		'label'	=> __('Add Address','medical-hospital'),
		'section'	=> 'medical_hospital_topbar_icon',
		'setting'	=> 'medical_hospital_address',
		'type'		=> 'text'
	));	

	//home page slider
	$wp_customize->add_section( 'medical_hospital_slidersettings' , array(
    	'title'      => __( 'Slider Settings', 'medical-hospital' ),
		'priority'   => null,
		'panel' => 'medical_hospital_panel_id'
	) );

	for ( $count = 1; $count <= 4; $count++ ) {

		// Add color scheme setting and control.
		$wp_customize->add_setting( 'medical_hospital_slidersettings-page-' . $count, array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );

		$wp_customize->add_control( 'medical_hospital_slidersettings-page-' . $count, array(
			'label'    => __( 'Select Slide Image Page', 'medical-hospital' ),
			'section'  => 'medical_hospital_slidersettings',
			'type'     => 'dropdown-pages'
		) );
	}

	//Service
	$wp_customize->add_section('medical_hospital_services',array(
		'title'	=> __('Services Section','medical-hospital'),
		'description'	=> __('Add Services sections below.','medical-hospital'),
		'panel' => 'medical_hospital_panel_id',
	));	
	
	$categories = get_categories();
	$cats = array();
	$i = 0;
	foreach($categories as $category){
	if($i==0){
	$default = $category->slug;
	$i++;
	}
	$cats[$category->slug] = $category->name;
	}

	$wp_customize->add_setting('medical_hospital_services',array(
		'default'	=> 'select',
		'sanitize_callback' => 'medical_hospital_sanitize_choices',
	));
	$wp_customize->add_control('medical_hospital_services',array(
		'type'    => 'select',
		'choices' => $cats,
		'label' => __('Select Category to display Latest Post','medical-hospital'),
		'section' => 'medical_hospital_services',
	));

	//About
	$wp_customize->add_section('medical_hospital_about1',array(
		'title'	=> __('About Section','medical-hospital'),
		'description'	=> __('Add About sections below.','medical-hospital'),
		'panel' => 'medical_hospital_panel_id',
	));

	$post_list = get_posts();
	$i = 0;
	foreach($post_list as $post){
		$posts[$post->post_title] = $post->post_title;
	}

	$wp_customize->add_setting('medical_hospital_about_setting',array(
		'sanitize_callback' => 'medical_hospital_sanitize_choices',
	));

	$wp_customize->add_control('medical_hospital_about_setting',array(
		'type'    => 'select',
		'choices' => $posts,
		'label' => __('Select post','medical-hospital'),
		'section' => 'medical_hospital_about1',
	));

	//footer text
	$wp_customize->add_section('medical_hospital_footer_section',array(
		'title'	=> __('Footer Text','medical-hospital'),
		'description'	=> __('Add some text for footer like copyright etc.','medical-hospital'),
		'panel' => 'medical_hospital_panel_id'
	));
	
	$wp_customize->add_setting('medical_hospital_text',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));	
	$wp_customize->add_control('medical_hospital_text',array(
		'label'	=> __('Copyright Text','medical-hospital'),
		'section'	=> 'medical_hospital_footer_section',
		'type'		=> 'text'
	));	
}
add_action( 'customize_register', 'medical_hospital_customize_register' );	

/**
 * Singleton class for handling the theme's customizer integration.
 *
 * @since  1.0.0
 * @access public
 */
final class Medical_Hospital_Customize {

	/**
	 * Returns the instance.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return object
	 */
	public static function get_instance() {

		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self;
			$instance->setup_actions();
		}

		return $instance;
	}

	/**
	 * Constructor method.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function __construct() {}

	/**
	 * Sets up initial actions.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function setup_actions() {

		// Register panels, sections, settings, controls, and partials.
		add_action( 'customize_register', array( $this, 'sections' ) );

		// Register scripts and styles for the controls.
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_control_scripts' ), 0 );
	}

	/**
	 * Sets up the customizer sections.
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  object  $manager
	 * @return void
	 */
	public function sections( $manager ) {

		// Load custom sections.
		load_template( trailingslashit( get_template_directory() ) . '/inc/section-pro.php' );

		// Register custom section types.
		$manager->register_section_type( 'Medical_Hospital_Customize_Section_Pro' );

		// Register sections.
		$manager->add_section(
			new Medical_Hospital_Customize_Section_Pro(
			$manager,
			'example_1',
				array(
				'priority'   => 9,
				'title'    => esc_html__( 'Medical Hospital Pro', 'medical-hospital' ),
				'pro_text' => esc_html__( 'Go Pro', 'medical-hospital' ),
				'pro_url'  => esc_url('https://www.themesglance.com/themes/premium-medical-wordpress-theme/')					
				)
			)
		);
	}

	/**
	 * Loads theme customizer CSS.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function enqueue_control_scripts() {

		wp_enqueue_script( 'medical-hospital-customize-controls', trailingslashit( get_template_directory_uri() ) . '/js/customize-controls.js', array( 'customize-controls' ) );

		wp_enqueue_style( 'medical-hospital-customize-controls', trailingslashit( get_template_directory_uri() ) . '/css/customize-controls.css' );
	}
}

// Doing this customizer thang!
Medical_Hospital_Customize::get_instance();