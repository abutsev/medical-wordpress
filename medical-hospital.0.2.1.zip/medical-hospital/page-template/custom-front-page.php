<?php
/**
 * Template Name: Custom home page
 */

get_header(); ?>

<?php do_action('medical_hospital_above_contact_section'); ?>

<section id="contact-us">
  <div class="container"> 
    <div class="row">   
      <div class="col-md-4 col-sm-4">
        <?php if( get_theme_mod( 'medical_hospital_time','' ) != '') { ?>
        <div class="row">
          <div class="col-md-2 col-sm-2">
            <i class="far fa-clock"></i>
          </div>
          <div class="col-md-10 col-sm-10">
            <p class="diff-lay"><?php echo esc_html( get_theme_mod('medical_hospital_time','') ); ?></p>
            <p class="diff-lay"><?php echo esc_html( get_theme_mod('medical_hospital_time1','') ); ?></p>
          </div>
        </div>
        <?php }?>
      </div>
      <div class="col-md-4 col-sm-4">
        <?php if( get_theme_mod( 'medical_hospital_phone','' ) != '') { ?>
        <div class="row">
          <div class="col-md-2 col-sm-2">
            <i class="fas fa-phone-volume"></i>
          </div>
          <div class="col-md-10 col-sm-10">
            <p class="diff-lay"><?php echo esc_html( get_theme_mod('medical_hospital_phone','') ); ?></p>
            <p class="diff-lay"><?php echo esc_html( get_theme_mod('medical_hospital_phone1','') ); ?></p>
          </div>
        </div>
        <?php }?>
      </div>   
      <div class="col-md-4 col-sm-4">
        <?php if( get_theme_mod( 'medical_hospital_address','' ) != '') { ?>
        <div class="row">
          <div class="col-md-2 col-sm-2">
            <i class="fas fa-map-marker-alt"></i>
          </div>
          <div class="col-md-10 col-sm-10">
            <p class="diff-lay"><?php echo esc_html( get_theme_mod('medical_hospital_address','') ); ?></p>        
          </div>
        </div>
        <?php }?>
      </div>
    </div>
  </div>
</section>

<?php do_action('medical_hospital_above_slider_section'); ?>

<div class="slider-main">
  <?php
    // Get pages set in the customizer (if any)
    $pages = array();
    for ( $medical_hospital_count = 1; $medical_hospital_count <= 5; $medical_hospital_count++ ) {
      $mod = absint( get_theme_mod( 'medical_hospital_slidersettings-page-' . $medical_hospital_count ) );
      if ( 'page-none-selected' != $mod ) {
        $pages[] = $mod;
      }
    }
    if( !empty($pages) ) :
      $args = array(
        'posts_per_page' => 5,
        'post_type' => 'page',
        'post__in' => $pages,
        'orderby' => 'post__in'
      );
      $query = new WP_Query( $args );
      if ( $query->have_posts() ) :
        $medical_hospital_count = 1;
        ?>
        <div id="slider" class="nivoSlider">
          <?php
            $medical_hospital_n = 0;
          while ( $query->have_posts() ) : $query->the_post();
              $medical_hospital_n++;
              $medical_hospital_slideno[] = $medical_hospital_n;
              $medical_hospital_slidetitle[] = esc_html(get_the_title());
              $medical_hospital_slidecontent[] = esc_html(get_the_excerpt());
              $medical_hospital_slidelink[] = esc_url( get_permalink() );
              ?>
                <img src="<?php the_post_thumbnail_url('full'); ?>" title="#slidecaption<?php echo esc_attr( $medical_hospital_n ); ?>" />
              <?php
            $medical_hospital_count++;
          endwhile;
          wp_reset_postdata();
          ?>
        </div>
        <?php
        $medical_hospital_k = 0;
          foreach( $medical_hospital_slideno as $medical_hospital_sln ){ ?>
            <div id="slidecaption<?php echo absint( $medical_hospital_sln ); ?>" class="nivo-html-caption">
              <div class="slide-cap  ">
                <div class="container">
                  <h2><?php echo esc_html( $medical_hospital_slidetitle[$medical_hospital_k] ); ?></h2>
                  <p><?php echo esc_html( $medical_hospital_slidecontent[$medical_hospital_k] ); ?></p>
                  <div class="read">
                    <a class="read-more" href="<?php echo esc_url( $medical_hospital_slidelink[$medical_hospital_k] ); ?>"><?php esc_html_e( 'READ MORE','medical-hospital' ); ?></a>
                  </div>
                </div>
              </div>
            </div>
            <?php $medical_hospital_k++;
        }
      else : ?>
          <div class="header-no-slider"></div>
        <?php
      endif;
    else : ?>
        <div class="header-no-slider"></div>
    <?php
    endif; 
  ?>
</div>

<?php do_action('medical_hospital_below_slider_section'); ?>

<div class="services">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1 top-service row">
        <?php 
          $page_query = new WP_Query(array( 'category_name' => esc_html(get_theme_mod('medical_hospital_services'),'theblog')));?>
          <?php while( $page_query->have_posts() ) : $page_query->the_post(); ?>
              <div class="col-md-3 col-sm-3 main-service-box">
                <div class="service-box">
                  <div class="abt-img-box"><?php if(has_post_thumbnail()) { ?><?php the_post_thumbnail(); ?><?php } ?></div>
                  <h4><?php the_title(); ?></h4>
                  <a href="<?php the_permalink(); ?>"><i class="fas fa-arrow-right"></i></a>
                </div>
              </div>
          <?php endwhile;
          wp_reset_postdata();
        ?>
        <div class="clearfix"></div>
      </div>
    </div>
  </div>
</div>

<?php do_action('medical_hospital_below_service_section'); ?>

<?php /*--About Us--*/?>
<section class="about">
  <div class="container">
    <?php
      $args = array( 'name' => esc_html( get_theme_mod('medical_hospital_about_setting','')));
      $query = new WP_Query( $args );
      if ( $query->have_posts() ) :
        while ( $query->have_posts() ) : $query->the_post(); ?>
          <div class="row">
            <div class="col-md-6 col-sm-6">
              <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
              <div class="images_border">
                <img src="<?php echo esc_url( get_theme_mod('',get_template_directory_uri().'/images/border-image.png') ); ?>" alt="">
              </div>
              <div class="textbox">
                <p><?php the_excerpt(); ?></p>
                <a href="<?php the_permalink(); ?>"><?php esc_html_e('FIND OUT MORE','medical-hospital'); ?></a>
              </div>
            </div> 
            <div class="col-md-6 col-sm-6">
              <div class="abt-image">
                <img src="<?php the_post_thumbnail_url('full'); ?>"/>              
              </div>
            </div>   
          </div>                
        <?php endwhile; 
        wp_reset_postdata();?>
        <?php else : ?>
           <div class="no-postfound"></div>
        <?php
    endif; ?>
  </div>
</section>

<?php do_action('medical_hospital_after_about_section'); ?>

<div class="container">
  <?php while ( have_posts() ) : the_post(); ?>
    <?php the_content(); ?>
  <?php endwhile; // end of the loop. ?>
</div>

<?php get_footer(); ?>