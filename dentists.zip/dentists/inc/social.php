<?php if( ! defined( 'ABSPATH' ) ) exit;

	function dentists_social_section () { ?>

		<div class="social">
		
			<div class="fa-icons">
			
				<?php if (get_theme_mod( 'dentists_facebook' )) : ?>
					<a target="<?php if(esc_attr(get_theme_mod( 'dentists_social_link_type' )) == "_blank"){echo esc_attr(get_theme_mod( 'dentists_social_link_type' )); } else {echo "_self"; } ?>" href="<?php echo esc_url(get_theme_mod( 'dentists_facebook' )); ?>"><i class="fa fa-facebook-f"></i></a>
				<?php endif; ?>
							
				<?php if (get_theme_mod( 'dentists_twitter' )) : ?>
					<a target="<?php if(esc_attr(get_theme_mod( 'dentists_social_link_type' ))){echo esc_attr(get_theme_mod( 'dentists_social_link_type' )); } else {echo "_self"; } ?>" href="<?php echo esc_url(get_theme_mod( 'dentists_twitter' )) ?>"><i class="fa fa-twitter"></i></a>
				<?php endif; ?>
											
				<?php if (get_theme_mod( 'dentists_google' )) : ?>
					<a target="<?php if(esc_attr(get_theme_mod( 'dentists_social_link_type' ))){echo esc_attr(get_theme_mod( 'dentists_social_link_type' )); } else {echo "_self"; } ?>" href="<?php echo esc_url(get_theme_mod( 'dentists_google' )); ?>"><i class="fa fa-google-plus"></i></a>
				<?php endif; ?>
				
			</div>
	
		</div>
		
<?php }  ?>