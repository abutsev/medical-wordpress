<?php
/**
 * All Purpose Theme Customizer
 *
 * @package All Purpose
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function dentists_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	

/***********************************************************************************
 * Sanitize Functions
***********************************************************************************/
					
		function dentists_sanitize_checkbox( $input ) {
			if ( $input ) {
				return 1;
			}
			return 0;
		}
/***********************************************************************************/
		
		function dentists_sanitize_social( $input ) {
			$valid = array(
				'' => esc_attr__( ' ', 'dentists' ),
				'_self' => esc_attr__( '_self', 'dentists' ),
				'_blank' => esc_attr__( '_blank', 'dentists' ),
			);

			if ( array_key_exists( $input, $valid ) ) {
				return $input;
			} else {
				return '';
			}
		}
		
		
/***********************************************************************************
 * Social media option
***********************************************************************************/
 
		$wp_customize->add_section( 'dentists_social_section' , array(
			'title'       => __( 'Social Media', 'dentists' ),
			'description' => __( 'Social media buttons', 'dentists' ),
			'priority'   => 64,
		) );
		
		$wp_customize->add_setting( 'social_media_activate_header', array (
			'sanitize_callback' => 'dentists_sanitize_checkbox',
		) );
				
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_activate_header', array(
			'label'    => __( 'Activate Social Icons in Header:', 'dentists' ),
			'section'  => 'dentists_social_section',
			'settings' => 'social_media_activate_header',
			'type' => 'checkbox',
		) ) );
		
		$wp_customize->add_setting( 'social_media_activate', array (
			'sanitize_callback' => 'dentists_sanitize_checkbox',
		) );
				
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_activate', array(
			'label'    => __( 'Activate Social Icons in Footer:', 'dentists' ),
			'section'  => 'dentists_social_section',
			'settings' => 'social_media_activate',
			'type' => 'checkbox',
		) ) );
		
		$wp_customize->add_setting( 'dentists_social_link_type', array (
			'sanitize_callback' => 'dentists_sanitize_social',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'dentists_social_link_type', array(
			'label'    => __( 'Link Type', 'dentists' ),
			'section'  => 'dentists_social_section',
			'settings' => 'dentists_social_link_type',
			'type'     =>  'select',
            'choices'  => array(
				'' => esc_attr__( ' ', 'dentists' ),
				'_self' => esc_attr__( '_self', 'dentists' ),
				'_blank' => esc_attr__( '_blank', 'dentists' ),
            ),			
		) ) );
		
		$wp_customize->add_setting( 'social_media_color', array (
			'sanitize_callback' => 'sanitize_hex_color',
		) );
				
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'social_media_color', array(
			'label'    => __( 'Social Icons Color:', 'dentists' ),
			'section'  => 'dentists_social_section',
			'settings' => 'social_media_color',
		) ) );
				
		$wp_customize->add_setting( 'social_media_hover_color', array (
			'sanitize_callback' => 'sanitize_hex_color',
		) );
				
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'social_media_hover_color', array(
			'label'    => __( 'Social Hover Icons Color:', 'dentists' ),
			'section'  => 'dentists_social_section',
			'settings' => 'social_media_hover_color',
		) ) );
		
		$wp_customize->add_setting( 'dentists_facebook', array (
			'sanitize_callback' => 'esc_url_raw',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'dentists_facebook', array(
			'label'    => __( 'Enter Facebook url', 'dentists' ),
			'section'  => 'dentists_social_section',
			'settings' => 'dentists_facebook',
		) ) );
	
		$wp_customize->add_setting( 'dentists_twitter', array (
			'sanitize_callback' => 'esc_url_raw',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'dentists_twitter', array(
			'label'    => __( 'Enter Twitter url', 'dentists' ),
			'section'  => 'dentists_social_section',
			'settings' => 'dentists_twitter',
		) ) );

		$wp_customize->add_setting( 'dentists_google', array (
			'sanitize_callback' => 'esc_url_raw',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'dentists_google', array(
			'label'    => __( 'Enter Google+ url', 'dentists' ),
			'section'  => 'dentists_social_section',
			'settings' => 'dentists_google',
		) ) );
	
		
/***********************************************************************************
 * Sidebar Options
***********************************************************************************/
 
		$wp_customize->add_section( 'dentists_sidebar' , array(
			'title'       => __( 'Sidebar Options', 'dentists' ),
			'priority'   => 64,
		) );
		
		$wp_customize->add_setting( 'dentists_sidebar_width', array (
			'sanitize_callback' => 'sanitize_text_field',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'dentists_sidebar_width', array(
			'label'    => __( 'Sidebar Width:', 'dentists' ),
			'section'  => 'dentists_sidebar',		
			'settings' => 'dentists_sidebar_width',
			'type'     =>  'range',		
			'input_attrs'     => array(
				'min'  => 10,
				'max'  => 50,
				'step' => 1,
	),			
		) ) );
		
		$wp_customize->add_setting( 'dentists_sidebar_position', array (
			'sanitize_callback' => 'sanitize_text_field',
		) );
				
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'dentists_sidebar_position', array(
			'label'    => __( 'Sidebar Position', 'dentists' ),
			'section'  => 'dentists_sidebar',
			'settings' => 'dentists_sidebar_position',
			'type' => 'radio',
			'choices' => array(
				'1' => __( 'Left', 'dentists' ),
				'2' => __( 'Right', 'dentists' ),
				'3' => __( 'No Sidebar', 'dentists' ),
				),			
			
		) ) );
		
/********************************************
* Sidebar Title Background
*********************************************/ 
	
		$wp_customize->add_setting('dentists_aside_background_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'dentists_aside_background_color', array(
		'label' => __('Sidebar Title Background Color', 'dentists'),        
		'section' => 'dentists_sidebar',
		'settings' => 'dentists_aside_background_color'
		)));
		
/********************************************
* Sidebar Title Color
*********************************************/ 
	
		$wp_customize->add_setting('dentists_aside_title_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'dentists_aside_title_color', array(
		'label' => __('Sidebar Title Color', 'dentists'),        
		'section' => 'dentists_sidebar',
		'settings' => 'dentists_aside_title_color'
		)));

/********************************************
* Sidebar Background
*********************************************/ 
	
		$wp_customize->add_setting('dentists_aside_background_color1', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'dentists_aside_background_color1', array(
		'label' => __('Sidebar Background Color', 'dentists'),        
		'section' => 'dentists_sidebar',
		'settings' => 'dentists_aside_background_color1'
		)));
		
/********************************************
* Sidebar Link Color
*********************************************/ 
	
		$wp_customize->add_setting('dentists_aside_link_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'dentists_aside_link_color', array(
		'label' => __('Sidebar Link Color', 'dentists'),        
		'section' => 'dentists_sidebar',
		'settings' => 'dentists_aside_link_color'
		)));
						
/********************************************
* Sidebar Link Hover Color
*********************************************/ 
	
		$wp_customize->add_setting('dentists_aside_link_hover_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'dentists_aside_link_hover_color', array(
		'label' => __('Sidebar Link Hover Color', 'dentists'),        
		'section' => 'dentists_sidebar',
		'settings' => 'dentists_aside_link_hover_color'
		)));
			
	
}
add_action( 'customize_register', 'dentists_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function dentists_customize_preview_js() {
	wp_enqueue_script( 'dentists_customizer', get_template_directory_uri() . '/framework/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'dentists_customize_preview_js' );


		function dentists_customize_all_css() {
    ?>
		<style type="text/css">
			<?php if ( (!is_front_page() or !is_home()) and get_theme_mod('custom_header_position') == "home") { ?> .site-header { display: none;} <?php } ?> 
			<?php if ( get_theme_mod('custom_header_position') == "deactivate") { ?> .site-header { display: none;} <?php } ?> 
			<?php if(get_theme_mod('dentists_aside_background_color')) { ?>#content aside h2 {background:<?php echo esc_attr (get_theme_mod('dentists_aside_background_color')); ?>;} <?php } ?> 
			<?php if(get_theme_mod('dentists_aside_background_color1')) { ?>#content aside ul, #content .widget {background:<?php echo esc_attr (get_theme_mod('dentists_aside_background_color1')); ?>;} <?php } ?> 
			<?php if(get_theme_mod('dentists_aside_title_color')) { ?>#content aside h2 {color:<?php echo esc_attr (get_theme_mod('dentists_aside_title_color')); ?>;} <?php } ?> 
			<?php if(get_theme_mod('dentists_aside_link_color')) { ?>#content aside a {color:<?php echo esc_attr (get_theme_mod('dentists_aside_link_color')); ?>;} <?php } ?> 
			<?php if(get_theme_mod('dentists_aside_link_hover_color')) { ?>#content aside a:hover {color:<?php echo esc_attr (get_theme_mod('dentists_aside_link_hover_color')); ?>;} <?php } ?> 
			
			<?php if(get_theme_mod('social_media_color')) { ?> .social .fa-icons i {color:<?php echo esc_attr (get_theme_mod('social_media_color')); ?> !important;} <?php } ?> 
			<?php if(get_theme_mod('social_media_hover_color')) { ?> .social .fa-icons i:hover {color:<?php echo esc_attr (get_theme_mod('social_media_hover_color')); ?> !important;} <?php } ?>

			<?php if(get_theme_mod('dentists_titles_setting_1')) { ?> .single-title, .sr-no-sidebar .entry-title, .full-p .entry-title { display: none !important;} <?php } ?>

		</style>
		
    <?php	
}
		add_action('wp_head', 'dentists_customize_all_css');
		
/**************************************
Sidebar Options
**************************************/


	function dentists_sidebar_width () {
		if(get_theme_mod('dentists_sidebar_width')) {
	
	$dentists_content_width = 96;
	$dentists_sidebar_width = esc_attr(get_theme_mod('dentists_sidebar_width'));
	$dentists_sidebar_sum = $dentists_content_width - $dentists_sidebar_width;

	?>
		<style>
			#content aside {width: <?php echo esc_attr(get_theme_mod('dentists_sidebar_width')); ?>% !important;}
			#content main {width: <?php echo esc_attr($dentists_sidebar_sum); ?>%  !important;}
		</style>
		
	<?php }
}
	add_action('wp_head','dentists_sidebar_width');
	

	
/*********************************************************************************************************
* Sidebar Position
**********************************************************************************************************/

	function dentists_sidebar(){
	$option_sidebar = get_theme_mod( 'dentists_sidebar_position');		
	if($option_sidebar == '2') { 
			wp_enqueue_style( 'seos-right-sidebar', get_template_directory_uri() . '/css/right-sidebar.css');
		}

	$option_sidebar = get_theme_mod( 'dentists_sidebar_position');			
		if($option_sidebar == '3') { 
			wp_enqueue_style( 'seos-no-sidebar', get_template_directory_uri() . '/css/no-sidebar.css');
		}
	}
	add_action( 'wp_enqueue_scripts', 'dentists_sidebar' );
	
		
		
