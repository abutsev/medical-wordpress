<?php
if( ! defined( 'ABSPATH' ) ) exit;

/**
 * Functions
**/

require get_template_directory() . '/inc/init.php';
require get_template_directory() . '/inc/theme-functions.php';

/**
 * Note: Do not add any custom code here.
**/